#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>
/* REFER to "man 2 write" and "man 2 read" */

/* man 2 write
 * Syntax: ssize_t write(int fd, const void *buf, size_t count);
 * write() writes up to count bytes from the buffer starting at buf to the file referred to by the file descriptor fd
 * On success, the number of bytes written is returned.  On error, -1 is returned, and errno is set to indicate the cause of  the  error
 * If  count is zero and fd refers to a regular file, then write() may return a failure status
 */

/* man 2 read
 * Syntax: ssize_t read(int fd, void *buf, size_t count);
 * read() attempts to read up to count bytes from file descriptor fd into the buffer starting at buf.
 * On success, the number of bytes read is returned (zero indicates end of file), and the file position is advanced  by  this  number.
 * On  error, -1 is returned, and errno is set appropriately.  In this case, it is left unspecified whether the file position (if any)
 *  changes*/
 
 /* man 2 lseek
 lseek - move the read/write file offset
 Syntax: off_t lseek(int fildes, off_t offset, int whence);
 The lseek() function shall set the file offset for the open file description associated with the file descriptor fildes, as follows:

    If whence is SEEK_SET, the file offset shall be set to offset bytes.
    If whence is SEEK_CUR, the file offset shall be set to its current location plus offset.
    If whence is SEEK_END, the file offset shall be set to the size of the file plus offset.

The symbolic constants SEEK_SET, SEEK_CUR, and SEEK_END are defined in <unistd.h>.

The lseek() function shall allow the file offset to be set beyond the end of the existing data in the file. If data is later written at 
this point, subsequent reads of data in the gap shall return bytes with the value 0 until data is actually written into the gap.

Upon successful completion, the resulting offset, as measured in bytes from the beginning of the file, shall be returned. Otherwise, 
(off_t)-1 shall be returned, errno shall be set to indicate the error, and the file offset shall remain unchanged.
 */

/* Note: If we want to see the upadated result, without executing the user code twice, we can use lseek(), the implementation is
 * shown below
 */
struct handle {
        int rw1;
        int ro2;
};

void* test_thread1(void *arg)
{
      int ret, wr,fd1,fd2, buf[1024];
      char buf1[1024];
      fd1=((struct handle *)arg)->rw1;
      fd2=((struct handle *)arg)->ro2;
      printf("this is the rw param\n");
      ret = read(fd1,buf,sizeof(buf));
        if(ret<0)
        {
                perror("error in read");
                exit(6);
        }
        sprintf(buf1,"value of param1 is %s\n",buf);
        if(ret>0)
        {
                write(STDOUT_FILENO,buf1,sizeof(buf1));
        }
        wr = write(fd1,"10",sizeof("10")+1);
        printf("\n");
        close(fd1);

      printf("this is the ro param\n");
      ret = read(fd2,buf,sizeof(buf));
        if(ret<0)
        {
                perror("error in read");
                exit(6);
        }
        sprintf(buf1,"value of param2 is %s\n",buf);
        if(ret>0)
        {
                write(STDOUT_FILENO,buf1,sizeof(buf1));
        }
        printf("\n");
        close(fd2);
    pthread_exit(NULL);
}


pthread_t thid1,thid2,thid3,thid4,thid5;

int main()
{
	struct handle h1;
	struct handle h2;
	struct handle h3;
	struct handle h4;
	struct handle h5;
	int fd1,fd2,ret1;
	printf("\n****************** DEVICE-0 ******************");
	fd1 = open("/sys/kernel/kset_devices_custom/device0/param1",O_RDWR); 
        if(fd1<0)
	{
        	perror("error in opening");
             	exit(1);
        }

	fd2 = open("/sys/kernel/kset_devices_custom/device0/param2",O_RDONLY);
        if(fd2<0)
        {
                perror("error in opening");
                exit(1);
        }
	h1.rw1=fd1;
	h1.ro2=fd2;
	printf("%d,%d\n",h1.rw1,h1.ro2);
	ret1 = pthread_create(&thid1,NULL,test_thread1,(void *)&h1);
	if(ret1>0)
	{
	       	printf("error in thread creation\n");
	       	exit(1);
	}

	printf("\n****************** DEVICE-1 ******************");
        fd1 = open("/sys/kernel/kset_devices_custom/device1/param1",O_RDWR);
        if(fd1<0)
        {
                perror("error in opening");
                exit(1);
        }

        fd2 = open("/sys/kernel/kset_devices_custom/device1/param2",O_RDONLY);
        if(fd2<0)
        {
                perror("error in opening");
                exit(1);
        }
        h2.rw1=fd1;
        h2.ro2=fd2;

        ret1 = pthread_create(&thid2,NULL,test_thread1,(void *)&h2);
        if(ret1>0)
        {
                printf("error in thread creation\n");
                exit(1);
        }

	printf("\n****************** DEVICE-2 ******************");
        fd1 = open("/sys/kernel/kset_devices_custom/device2/param1",O_RDWR);
        if(fd1<0)
        {
                perror("error in opening");
                exit(1);
        }

        fd2 = open("/sys/kernel/kset_devices_custom/device2/param2",O_RDONLY);
        if(fd2<0)
        {
                perror("error in opening");
                exit(1);
        }
        h3.rw1=fd1;
        h3.ro2=fd2;

        ret1 = pthread_create(&thid3,NULL,test_thread1,(void *)&h3);
        if(ret1>0)
        {
                printf("error in thread creation\n");
                exit(1);
        }
        
        printf("\n****************** DEVICE-3 ******************");
	fd1 = open("/sys/kernel/kset_devices_custom/device3/param1",O_RDWR); 
        if(fd1<0)
	{
        	perror("error in opening");
             	exit(1);
        }

	fd2 = open("/sys/kernel/kset_devices_custom/device3/param2",O_RDONLY);
        if(fd2<0)
        {
                perror("error in opening");
                exit(1);
        }
	h4.rw1=fd1;
	h4.ro2=fd2;
	printf("%d,%d\n",h4.rw1,h4.ro2);
	ret1 = pthread_create(&thid4,NULL,test_thread1,(void *)&h4);
	if(ret1>0)
	{
	       	printf("error in thread creation\n");
	       	exit(1);
	}
        
        
        printf("\n****************** DEVICE-4 ******************");
	fd1 = open("/sys/kernel/kset_devices_custom/device4/param1",O_RDWR); 
        if(fd1<0)
	{
        	perror("error in opening");
             	exit(1);
        }

	fd2 = open("/sys/kernel/kset_devices_custom/device4/param2",O_RDONLY);
        if(fd2<0)
        {
                perror("error in opening");
                exit(1);
        }
	h5.rw1=fd1;
	h5.ro2=fd2;
	printf("%d,%d\n",h5.rw1,h5.ro2);
	ret1 = pthread_create(&thid5,NULL,test_thread1,(void *)&h5);
	if(ret1>0)
	{
	       	printf("error in thread creation\n");
	       	exit(1);
	}

        pthread_join(thid1,NULL);
	pthread_join(thid2,NULL);
	pthread_join(thid3,NULL);
        pthread_join(thid4,NULL);
	pthread_join(thid5,NULL);



}
