#!/bin/bash
#step_1
echo 0  > /sys/kernel/debug/tracing/tracing_on 
cat  /sys/kernel/debug/tracing/tracing_on
#step_2
#cat  /sys/kernel/debug/tracing/trace_pipe 
echo function >  /sys/kernel/debug/tracing/current_tracer
#step_3
sudo insmod kset_ex.ko
#step_4
echo '*:mod:kset_ex' >> /sys/kernel/debug/tracing/set_ftrace_filter
cat /sys/kernel/debug/tracing/set_ftrace_filter
#step_5
cat /proc/kallsyms | grep -v   ']' | less
#step_6
echo proc_reg_*  >> /sys/kernel/debug/tracing/set_ftrace_filter 
cat /sys/kernel/debug/tracing/set_ftrace_filter
echo seq_*  >> /sys/kernel/debug/tracing/set_ftrace_filter 
cat /sys/kernel/debug/tracing/set_ftrace_filter
#step_7
echo  vfs_open >> /sys/kernel/debug/tracing/set_ftrace_filter 
echo  do_dentry_open >> /sys/kernel/debug/tracing/set_ftrace_filter
echo  __vfs_read >> /sys/kernel/debug/tracing/set_ftrace_filter
echo  vfs_read >> /sys/kernel/debug/tracing/set_ftrace_filter
echo  ksys_read >> /sys/kernel/debug/tracing/set_ftrace_filter
echo  sys_read >> /sys/kernel/debug/tracing/set_ftrace_filter
echo foo_show >> /sys/kernel/debug/tracing/set_ftrace_filter
echo foo_store >> /sys/kernel/debug/tracing/set_ftrace_filter
echo sysfs_kf_write >> /sys/kernel/debug/tracing/set_ftrace_filter
echo kernfs_fop_write >> /sys/kernel/debug/tracing/set_ftrace_filter
echo __vfs_write >> /sys/kernel/debug/tracing/set_ftrace_filter
echo vfs_write >> /sys/kernel/debug/tracing/set_ftrace_filter
echo ksys_write >> /sys/kernel/debug/tracing/set_ftrace_filter
echo sys_write >> /sys/kernel/debug/tracing/set_ftrace_filter
#step_8
cat   /sys/kernel/debug/tracing/set_ftrace_filter
#step_9
echo 1  > /sys/kernel/debug/tracing/tracing_on 
#step_10
./kset1
#step_11
echo 0  > /sys/kernel/debug/tracing/tracing_on
#step_12
cat /sys/kernel/debug/tracing/trace | less
cat /sys/kernel/debug/tracing/trace | grep 'kset1' > test3.txt
#cat /sys/kernel/debug/tracing/trace | grep 'proc_seq_test_15' > kep_v1.txt
cat /sys/kernel/debug/tracing/trace_pipe
