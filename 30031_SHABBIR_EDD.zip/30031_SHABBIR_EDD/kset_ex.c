#include <linux/kobject.h>
#include <linux/string.h>
#include <linux/sysfs.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>

struct custom_obj {
    struct kobject kobj;
    int value1;
    int value2;
    int value3;
};

#define to_custom_obj(x) container_of(x, struct custom_obj, kobj)

struct custom_attribute {
    struct attribute attr;
    ssize_t (*show)(struct custom_obj *c_obj, struct custom_attribute *attr, char *buf);
    ssize_t (*store)(struct custom_obj *c_obj, struct custom_attribute *attr, const char *buf, size_t count);
};

#define to_custom_attr(x) container_of(x, struct custom_attribute, attr)
//************************************************************************************
//
//
//
static ssize_t custom_attr_show(struct kobject *kobj, struct attribute *attr, char *buf) {
    struct custom_attribute *attribute;
    struct custom_obj *c_obj;

    attribute = to_custom_attr(attr);
    c_obj = to_custom_obj(kobj);

    if (!attribute->show)
        return -EIO;

    return attribute->show(c_obj, attribute, buf);
}

static ssize_t custom_attr_store(struct kobject *kobj, struct attribute *attr, const char *buf, size_t len) {
    struct custom_attribute *attribute;
    struct custom_obj *c_obj;

    attribute = to_custom_attr(attr);
    c_obj = to_custom_obj(kobj);

    if (!attribute->store)
        return -EIO;

    return attribute->store(c_obj, attribute, buf, len);
}
//*************************************************************************************************
//
//
static struct sysfs_ops custom_sysfs_ops = {
    .show = custom_attr_show,
    .store = custom_attr_store,
};

static void custom_release(struct kobject *kobj) {
    struct custom_obj *c_obj;
    c_obj = to_custom_obj(kobj);
    kfree(c_obj);
}



//*******************************************************************************************
static ssize_t custom_show(struct custom_obj *c_obj, struct custom_attribute *attr,
		      char *buf)
{
	int var;
        dump_stack();
	if (strcmp(attr->attr.name, "dev_param1") == 0)
                var = c_obj->value1;
	if (strcmp(attr->attr.name, "dev_param2") == 0)
		var = c_obj->value2;
	else
		var = c_obj->value3;
	printk("data  is %d\n", var);
	return sprintf(buf, "%d\n", var);
}

static ssize_t custom_store(struct custom_obj *c_obj, struct custom_attribute *attr,
		       const char *buf, size_t count)
{
	int var;

        dump_stack();
	sscanf(buf, "%du", &var);
	if (strcmp(attr->attr.name, "dev_param1") == 0)
                c_obj->value1 = var;
	if (strcmp(attr->attr.name, "dev_param2") == 0)
		c_obj->value2 = var;
	else
		c_obj->value3 = var;
	printk("data  is %d\n", var);
	return count;
}

//***********************************************************************************************
//
//
//
//
//
static struct custom_attribute custom_attribute = __ATTR(param1, 0600, custom_show, custom_store);
static struct custom_attribute another_attribute = __ATTR(param2, 0400, custom_show, NULL);

static struct attribute *custom_default_attrs[] = {
    &custom_attribute.attr,
    &another_attribute.attr,
    NULL,
};

static struct kobj_type custom_ktype = {
    .sysfs_ops = &custom_sysfs_ops,
    .release = custom_release,
    .default_attrs = custom_default_attrs,
};






static struct kset *example_kset;
static struct custom_obj *obj1;
static struct custom_obj *obj2;
static struct custom_obj *obj3;
static struct custom_obj *obj4;
static struct custom_obj *obj5;

static struct custom_obj *create_custom_obj(const char *name) {
    struct custom_obj *c_obj;
    int retval;

    c_obj = kzalloc(sizeof(*c_obj), GFP_KERNEL);
    if (!c_obj)
        return NULL;

    c_obj->kobj.kset = example_kset;

    retval = kobject_init_and_add(&c_obj->kobj, &custom_ktype, NULL, "%s", name);
    if (retval) {
        kfree(c_obj);
        return NULL;
    }

    return c_obj;
}

static void destroy_custom_obj(struct custom_obj *c_obj) {
    kobject_put(&c_obj->kobj);
}

static int example_init(void) {
    example_kset = kset_create_and_add("kset_devices_custom", NULL, kernel_kobj);
    if (!example_kset)
        return -ENOMEM;

    obj1 = create_custom_obj("device0");
    if (!obj1)
        goto obj1_error;

    obj2 = create_custom_obj("device1");
    if (!obj2)
        goto obj2_error;

    obj3 = create_custom_obj("device2");
    if (!obj3)
        goto obj3_error;

    obj4 = create_custom_obj("device3");
    if (!obj4)
        goto obj4_error;

    obj5 = create_custom_obj("device4");
    if (!obj5)
        goto obj5_error;

    return 0;



obj5_error:
    destroy_custom_obj(obj4);
obj4_error:
    destroy_custom_obj(obj3);
obj3_error:
    destroy_custom_obj(obj2);
obj2_error:
    destroy_custom_obj(obj1);
obj1_error:
    
    return -EINVAL;
}





static void example_exit(void) {
    destroy_custom_obj(obj5);
    destroy_custom_obj(obj4);
    destroy_custom_obj(obj3);
    destroy_custom_obj(obj2);
    destroy_custom_obj(obj1);
    kset_unregister(example_kset);
}

module_init(example_init);
module_exit(example_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Greg Kroah-Hartman <greg@kroah.com>");

