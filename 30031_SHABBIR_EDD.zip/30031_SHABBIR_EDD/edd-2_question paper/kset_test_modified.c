
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>

/* REFER to "man 2 write" and "man 2 read" */

/* man 2 write
 * Syntax: ssize_t write(int fd, const void *buf, size_t count);
 * write() writes up to count bytes from the buffer starting at buf to the file referred to by the file descriptor fd
 * On success, the number of bytes written is returned.  On error, -1 is returned, and errno is set to indicate the cause of  the  error
 * If  count is zero and fd refers to a regular file, then write() may return a failure status
 */

/* man 2 read
 * Syntax: ssize_t read(int fd, void *buf, size_t count);
 * read() attempts to read up to count bytes from file descriptor fd into the buffer starting at buf.
 * On success, the number of bytes read is returned (zero indicates end of file), and the file position is advanced  by  this  number.
 * On  error, -1 is returned, and errno is set appropriately.  In this case, it is left unspecified whether the file position (if any)
 *  changes*/
 
 /* man 2 lseek
 lseek - move the read/write file offset
 Syntax: off_t lseek(int fildes, off_t offset, int whence);
 The lseek() function shall set the file offset for the open file description associated with the file descriptor fildes, as follows:

    If whence is SEEK_SET, the file offset shall be set to offset bytes.
    If whence is SEEK_CUR, the file offset shall be set to its current location plus offset.
    If whence is SEEK_END, the file offset shall be set to the size of the file plus offset.

The symbolic constants SEEK_SET, SEEK_CUR, and SEEK_END are defined in <unistd.h>.

The lseek() function shall allow the file offset to be set beyond the end of the existing data in the file. If data is later written at 
this point, subsequent reads of data in the gap shall return bytes with the value 0 until data is actually written into the gap.

Upon successful completion, the resulting offset, as measured in bytes from the beginning of the file, shall be returned. Otherwise, 
(off_t)-1 shall be returned, errno shall be set to indicate the error, and the file offset shall remain unchanged.
 */

/* Note: If we want to see the upadated result, without executing the user code twice, we can use lseek(), the implementation is
 * shown below
 */

int main()
{
	int fd, ret, wr, buf[1024];
	printf("\n****************** DEVICE-0 ******************");
	fd = open("/sys/kernel/kset_devices_typeA/device0/dev_param1",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param1 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"10",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/********************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device0/dev_param2",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param2 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"20",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/*************************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device0/dev_param3",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param3 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"30",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/*****************************************************************************************************************************/

	printf("\n****************** DEVICE-1 ******************");
	fd = open("/sys/kernel/kset_devices_typeA/device1/dev_param1",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param1 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"40",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/********************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device1/dev_param2",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param2 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"50",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/*************************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device1/dev_param3",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param3 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"60",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/*******************************************************************************************************************************/

	printf("\n****************** DEVICE-2 ******************");
	fd = open("/sys/kernel/kset_devices_typeA/device2/dev_param1",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param1 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"70",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/********************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device2/dev_param2",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param2 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"80",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
/*************************************************************************************************************/

	fd = open("/sys/kernel/kset_devices_typeA/device2/dev_param3",O_RDWR); 
        if(fd<0)
	{
        	perror("error in opening");
             	exit(1);
        }

        ret = read(fd,buf,1024);
     
        if(ret<0)
	{
		perror("error in read"); 
              	exit(6);
	}
 	printf("\nvalue of dev_param3 is %s\n");

	if(ret>0)
	{
		write(STDOUT_FILENO,buf,ret);
	} 

	wr = write(fd,"90",sizeof(buf));
	/*	lseek(fd,0,SEEK_SET);
     		ret = read(fd,buf,1024);     
      		if(ret<0)
		{
			perror("error in read"); 
                 	exit(6);
		}
     		printf("\n New value  dev_param1 is %s\n"); 
     		if(ret>0) 
        	{
        		write(STDOUT_FILENO,buf,ret); 
        	}*/
   	printf("\n");
   	close(fd);
}
