#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>
#include<stdio.h>
#include<stdlib.h>

/* REFER to "man 2 write" and "man 2 read" */

/* man 2 write
 * Syntax: ssize_t write(int fd, const void *buf, size_t count);
 * write() writes up to count bytes from the buffer starting at buf to the file referred to by the file descriptor fd
 * On success, the number of bytes written is returned.  On error, -1 is returned, and errno is set to indicate the cause of  the  error
 * If  count is zero and fd refers to a regular file, then write() may return a failure status
 */

/* man 2 read
 * Syntax: ssize_t read(int fd, void *buf, size_t count);
 * read() attempts to read up to count bytes from file descriptor fd into the buffer starting at buf.
 * On success, the number of bytes read is returned (zero indicates end of file), and the file position is advanced  by  this  number.
 * On  error, -1 is returned, and errno is set appropriately.  In this case, it is left unspecified whether the file position (if any)
 *  changes*/

int main()
{
	int fd,ret,buf[1024],wr;
	fd = open("/sys/kernel/kobject_example1/foo",O_RDWR); //accessing an attribute file
                                                              //-->it is a sysfs file ??
   	if(fd<0)
	{
        	perror("error in opening");
        	exit(1);
   	}
		ret = read(fd,buf,sizeof(buf));  //reading an attribute's active file ??
    		if(ret<0) 
		{
		       	perror("error in read");
		       	exit(2);
	       	}
		printf("the value in foo is %s\n" );
   		if(ret>0)
       		{
	       		write(STDOUT_FILENO,buf,ret);
       		}	 	
	wr = write(fd, "0030", sizeof(buf)); //writing an attribute's active file ??
  	close(fd); 

/***********************************************************************************************************************************/

	fd = open("/sys/kernel/kobject_example1/bar",O_RDWR);
   	if(fd<0)
	{
        	perror("error in opening");
           	exit(1);
   	}
 		ret = read(fd,buf,sizeof(buf));
    		if(ret<0)
	       	{
		       	perror("error in read");
		       	exit(2);
	       	}
   		printf("the value in bar is %s\n" );
   		if(ret>0)
	       	{
		       	write(STDOUT_FILENO,buf,ret);
	       	} 
	wr = write(fd, "0053", sizeof(buf)); 
  	close(fd); 

/************************************************************************************************************************************/

	fd = open("/sys/kernel/kobject_example1/baz",O_RDWR);
   	if(fd<0)
	{
          	 perror("error in opening");
           	 exit(1);
   	}
		ret = read(fd,buf,sizeof(buf));
    		if(ret<0)
	       	{
		       	perror("error in read");
		       	exit(2);
	       	}
   		printf("the value in baz is :%s\n" );
   		if(ret>0)
	       	{
		       	write(STDOUT_FILENO,buf,ret);
	       	} 
	wr = write(fd, "0056", sizeof(buf)); 
  	close(fd); 

exit(0);
}
