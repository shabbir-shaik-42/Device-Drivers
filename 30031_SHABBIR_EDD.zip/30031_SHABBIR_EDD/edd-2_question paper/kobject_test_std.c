#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int wr,fd[5],ret,buf[4096];
	
	//for device_param1
	
	fd[0] = open("/sys/kernel/kobject_example/device_param1",O_RDWR);
	if(fd[0]<0){//if there is an error, we will terminate the processi
           perror("error in opening");
           exit(1);
   	}
	printf("value of fd[0] is %d\n", fd[0]);
	
	ret = read(fd[0],buf,64); //this will be a read call, which will 
                                  //trigger show() method of an struct kobj_attribute{}/
                                  //struct attribute{} and collect data   
	if(ret < 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret>0){ 
		write(STDOUT_FILENO,buf,ret); 
               
	} 
	
	wr = write(fd[0], "0015", strlen("0015")+1); //writing an attribute's active file ??
	if(wr < 0){                                  //it will trigger store call-back of
                                                     //struct kobj_attribute{}/struct attribute{}
		printf("error in writing\n");
		exit(1);
	}
	
	// lseek --> file pointer to zero - we must reset an internal offset
        //           of an active-file
        //
	ret = lseek(fd[0],0,SEEK_SET);	

        //now, we can read the updated data from our attribute/call-back
        //
	ret = read(fd[0],buf,20);
	if(ret < 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret>0){ 
		write(STDOUT_FILENO,buf,ret); 
	} 
	
	//for device_param2
        //	
	fd[1] = open("/sys/kernel/kobject_example/device_param2",O_RDWR);
	if(fd[1]<0){//if there is an error, we will terminate the processi
           perror("error in opening");
           exit(1);
   	}
	printf("value of fd is %d\n", fd[1]);
	ret = read(fd[1],buf,20);
	if(ret< 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret > 0){ 
		write(STDOUT_FILENO,buf,ret); 
	} 

        //modify the data of this attribute 
        //
        //use lseek() to reset active-file 
        //
        //read and print, again ??


	
	//for device_param3
	
	fd = open("/sys/kernel/kobject_example/device_param3",O_RDWR);
	if(fd < 0){//if there is an error, we will terminate the processi
           perror("error in opening");
           exit(1);
	}
	printf("value of fd is %d\n", fd);
	ret = read(fd,buf,20);
	if(ret < 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret>0){ 
		write(STDOUT_FILENO,buf,ret); 
	} 

        //modify the data of this attribute 
        //
        //use lseek() to reset active-file 
        //
        //read and print, again ??

	

	// for device_param4
//	fd = open("/sys/kernel/kobject_example/device_param3",O_RDWR);// since it has only read permission
								      // this won't allow to open file
	               						      // error in opening: Permission denied
	fd = open("/sys/kernel/kobject_example/device_param4",O_RDONLY);
	if(fd < 0){//if there is an error, we will terminate the processi
           perror("error in opening");
           exit(1);
	}
	printf("value of fd is %d\n", fd);
	ret = read(fd,buf,20);
	if(ret < 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret>0){ 
		write(STDOUT_FILENO,buf,ret); 
	} 
	
	// for device_param5
	fd = open("/sys/kernel/kobject_example/device_param5",O_RDWR);
	if(fd < 0){//if there is an error, we will terminate the processi
           perror("error in opening");
           exit(1);
	}
	printf("value of fd is %d\n", fd);
	ret = read(fd,buf,20);
	if(ret < 0){
  		printf("error in read\n");
		exit(1);
  	} 
  	printf("the no. characters returned is %d\n", ret);
	if(ret>0){ 
		write(STDOUT_FILENO,buf,ret); 
	} 

       //modify the data of this attribute
       //
       //use lseek() to reset active-file
       //
       //read and print, again ??
	

      
       //finally, we can delete active files, using close() system-call API 
       //
       //close(fd[0]);
       //close(fd[1]);
       //close(fd[2]);
       //close(fd[3]);
       //close(fd[4]);
       //close(fd[5]);
 


	exit(0);

}
