/*
 * Sample kobject implementation
 *
 * Copyright (C) 2004-2007 Greg Kroah-Hartman <greg@kroah.com>
 * Copyright (C) 2007 Novell Inc.
 *
 * Released under the GPL version 2 only.
 *
 */
#include <linux/kobject.h>
#include <linux/string.h>
#include <linux/sysfs.h>
#include <linux/module.h>
#include <linux/init.h>

/*
 * This module shows how to create a simple subdirectory in sysfs called
 * /sys/kernel/kobject-example  In that directory, 3 files are created:
 * "foo", "baz", and "bar".  If an integer is written to these files, 
 *it can be
 * later read out of it.
 */
//these are dummy variables associated with 
//our attributes/device specific attributes(kobject-specific)
//
//in this simple code sample, dummy variables are represented, 
//using attribute{} objects(generic/abstract) and respective private/specific attribute
//objects, kobj_attribute{} objects(specific) 
//
//
//
static int foo=0; //in this simple example, foo attribute is linked to 
                //this foo variable - in more complex scenarios, 
                //an attribute will be linked to some parameter of 
                //a device, or a device-driver 
static int baz=0; //another variable associated with another attribute
//static char baz[32];
static int bar=0; //another variable associated with another attribute
//static char bar;  
int ret=0;
/*
 * The "foo" file where a static variable is read from and written to.
 */
//this is a typical, xxx_show() call-back - 
//this xxx_show() call back will be invoked, 
//as part of a kernel-execution path of a read() system - 
//call on an active sysfs-file of the associated struct attribute's
//sysfs, empty regular-file(in the demos. we use cat system utility, 
//or a typical, program ??)  
//
//like any call-back, this will be passed one,  or more 
//system-objects as parameters - these call-backs are re-entrant ?? 
//as per the context of execution of a KEP, this call-back will be
//passed different parameters' data, so there execution will be 
//re-entrant - we will cover re-entrancy, in multi-threading ?? 
//--->meaning, these call-backs will be invoked, in different process/thread
//    contexts , so will be invoked multiple-times, concurrently  
//
//p1 ---> pointer to a related kobject{} is passed
//p2 ---> pointer to a related kobj_attribute{} is passed 
//p3 ---> pointer to a kernel-buffer is passed - size is 4096 bytes ?? 
//
//
//a kernel buffer is passed, for reading an attribute's data -
//this kernel-buffer must be filled, as per rules - 
//the same kernel-buffer will be used to copy 
//data, into the user-space buffer of the 
//read() system call API - this job will be done, in the
//background
//
//this xxx_show() call back is associated, with 
//a device-specific attribute{},kobj_attribute{} and a dummy, 
//foo variable, in this code-sample - 
//so, foo variable is represented, using a struct attribute{} object and
//its struct kobj_attribute{} - in another scenario, this set-up will be
//different  
//
//below code is simple, but real-code will be more involved 
// 
static ssize_t foo_show(struct kobject *kobj, 
                        struct kobj_attribute *attr,
			char *buf)
{
        dump_stack();
        //we need to pass an "integer value", but format as a string 
        //and send it - this is the convention 
        //when the string is received, in the user-space, we must 
        //again extract the integer value, from the string  
	//printk("data string is %s\n", buf);
        
	if (strcmp(attr->attr.name, "device_param1") == 0)
        //
               ret= sprintf(buf, "%d", foo);
	if (strcmp(attr->attr.name, "bar") == 0)
        //
               ret= sprintf(buf, "%d", bar);
	if (strcmp(attr->attr.name, "baz") == 0)
        //
               ret= sprintf(buf, "%d", baz);
        printk("data string is %s\n", buf);
        return ret; //as per rules ??
       
}

//this is a typical, xxx_store() call-back - 
//this xxx_store() call-back will be invoked, 
//as part of a kernel-execution path of a write() system- 
//call on an active sysfs-file of a struct attribute's sysfs regular-file -
//we can use write() system-call API, in our program, or 
//we can use echo command to invoke write() system-call API, indirectly 
//
//like any call-back, this will be passed one,  or more 
//system-objects - these call-backs are re-entrant ?? 
//as per the context of execution of a KEP,  this call-back's 
//parameters' data will be different 
//
//a kernel-buffer is passed, for writing system-data - 
//this kernel-buffer must be filled, as per rules, in the 
//background, by some call-back  - we must collect this 
//buffer-data and update the value of correponding variable, or 
//a device-parameter 
//
//p1 -> pointer to a related struct kobject {}
//p2 -> pointer to a related struct kobj_attribute{}
//p3 -> pointer to a kernel-buffer containing data 
//p4 -> amount of data present, in this kernel-buffer
//
//in this simple call-back we just update our attribute's variable
//and return - in real-code, it will be more involved 
//
static ssize_t foo_store(struct kobject *kobj, struct kobj_attribute *attr,
			 const char *buf, size_t count)
{

        dump_stack();
	sscanf(buf, "%du", &foo);
	printk("data  is %d\n", foo);
	return count;
}

//in this code-sample, we associate our useful private, device-specific, 
//attribute object(struct kobj_attribute{}), 
//with an abstract struct attribute{} object - part of this frame-work - our
//device-specific attribute-object contains an abstract, 
//struct attribute {} object - so, our device-specific attribute object
//is struct kobj_attribute{} -  
//we also, associate a show() method and a store() method, with our 
//device-specific, attribute-object - together, this set-up will be effective, 
//as per frame-work  !!!
//see the code and comments above and below  ??
//in this context, struct kobj_attribute{} is a specific, attribute-
//object, for our device-instance - we can declare multiple instances, as 
//per our device-parameters, one per our device-specific parameter 
//
//
//in this context, following macros set-up   specific, 
//struct kobj_attribute{ } instances - so, we are setting-up
//device-specific attribute-objects, as per requirements
// 
//-->refer to <ksrctree>/include/linux/kobject.h 
//as part of this set-up, struct attribute{} fields are initialized, with
//a name-string  and multi-user access-permissions  - 
//the name-string and access-permissions are passed on to the 
//corresponding sysfs-files' meta-data and effectively used, in 
//sysfs regular-files.....  
//
//  
//in addition, one show call-back and one store call- 
//back are registered, along with each device-specific attribute- 
//object - call-backs' pointers are initialized - 
//call-backs are used, as per frame-works and rules, when we access 
//sysfs regular-files of struct attribute{} objects  
// 
//in the sysfs access permissions to "attribute/sysfs" regular files,
//the system may complain about 0666 and will support 
//0600 or 0644 or 0640 or 0604 - this could be for secure 
//access permissions  
//in older kernel versions, these security restrictions
//were minimal and in newer kernel versions, it is 
//very strict
//--->for 0644, read/write is allowed, for root-user and processes
//    for other users and processes, read-only access is provided 
//
//
//in the following set-up, using a kernel-macro,
//p1 will be used as name-string stored, in struct attribute{} of 
//this device-specific attribute-object - this name-string will be
//used to set the name of correponding sysfs regular-file -  
//p2 will be used as access permissions, 
//for sysfs regular-file of  struct attribute{} of  this 
//struct kobj_attribute{} -
//(stored, in struct attribute{} object, but passed to sysfs)
//p3 will  be used to pass pointer to a show call-back, which will 
//be stored, in this struct kobj_attribute{} instance - 
//p4 will  be used to pass pointer to a store call-back, which will
//be stored, in struct kobj_attribute{} instance
//--->refer to call-backs listed and described above ??
// 
static struct kobj_attribute foo_attribute =
	//__ATTR(foo, 0666, foo_show, foo_store);
	__ATTR(device_param1, 0640, foo_show, foo_store);
//	__ATTR(device_param1, 0600, foo_show, foo_store);
//	__ATTR(foo, 0644, foo_show, foo_store);

/*
 * More complex function where we determine which varible is being accessed by
 * looking at the attribute for the "baz" and "bar" files.
 */
//these are typically, re-entrant method
//
static ssize_t b_show(struct kobject *kobj, struct kobj_attribute *attr,
		      char *buf)
{
	int var;
        dump_stack();

	if (strcmp(attr->attr.name, "baz") == 0)
		var = baz;
	else
		var = bar;
	return sprintf(buf, "%d\n", var);
}

//these are typically, re-entrant method
//
static ssize_t b_store(struct kobject *kobj, struct kobj_attribute *attr,
		       const char *buf, size_t count)
{
	int var;
        dump_stack();

	sscanf(buf, "%du", &var);
	if (strcmp(attr->attr.name, "baz") == 0)
		baz = var;
	else
		bar = var;
	return count;
}

//one more device-specific attribute-object, which represents a baz variable
//using another struct attribute {} object 
static struct kobj_attribute baz_attribute =
//	__ATTR(device_param2, 0400, b_show, NULL);
	__ATTR(device_param2, 0400, foo_show, NULL);
//	__ATTR(baz, 0666, b_show, b_store);
//one more device-specific attribute-object 
//
static struct kobj_attribute bar_attribute =
	__ATTR(device_param3, 0600, foo_show, foo_store);
//	__ATTR(bar, 0666, b_show, b_store);

//one more device-specific attribute-object, which represents a baz variable
//using another struct attribute {} object 
//static struct kobj_attribute baz_attribute =
//	__ATTR(device_param2, 0400, foo_show, NULL);
//	__ATTR(baz, 0666, b_show, b_store);
//one more device-specific attribute-object 
//
//static struct kobj_attribute bar_attribute =
//	__ATTR(device_param3, 0600, foo_show, foo_store);
//	__ATTR(bar, 0666, b_show, b_store);


//static struct kobj_attribute bar_attribute =
//	__ATTR(device_param3, 0600, foo_show, foo_store);
static struct kobj_attribute device_param4_attribute =
	//__ATTR(/sys/kernel/kobject_example/device_param4, 0600, foo_show, foo_store);
	__ATTR(device_param4, 0600, foo_show, foo_store);
static struct kobj_attribute device_param5_attribute =
	__ATTR(device_param5, 0400, foo_show, NULL);
static struct kobj_attribute device_param6_attribute  =
	__ATTR(device_param6, 0600, foo_show, foo_store);



//the following objects are used to manage the attributes declared above 
//this is one way of setting up attributes - we will see another 
//method, in the next example !!!
/*
 * Create a group of attributes so that we can create and destory them all
 * at once.
 */
//
//we are collecting all the pointers of struct attribute objects of device-specific,
//attribute-objects, before registering, using sysfs_create_group() 
//
//most of the coding and data types are pre-defined, by 
//kernel frame-works 
//
//
static struct attribute *attrs[] = {
	&foo_attribute.attr,
	&baz_attribute.attr,
	&bar_attribute.attr,
	NULL,	/* need to NULL terminate the list of attributes */
};

/*
 * An unnamed attribute group will put all of the attributes directly in
 * the kobject directory.  If we specify a name, a subdirectory will be
 * created for the attributes with the directory being the name of the
 * attribute group.
 */
static struct attribute_group attr_group = {
	.attrs = attrs,
};

static struct kobject *example_kobj;
//
//in the below case, __init will add our init method's code to 
//.init section of our kernel module....this section will be 
//discarded, after the module is loaded....
//this will be memory efficient.....
//
//
static int __init example_init(void)
{
	int retval=0;

	/*
	 * Create a simple(dummy) kobject with the name of "kobject_example",
	 * located under /sys/kernel/
	 *
	 * As this is a simple directory, no uevent will be sent to
	 * userspace.  That is why this function should not be used for
	 * any type of dynamic kobjects, where the name and number are
	 * not known ahead of time.
	
         */
        //we may use kobjects directly, or we may use kobjects indirectly - 
        //we may use kobjects indirectly, 
        //using other container-objects of device-model ?? 
        //
        //a kobject can be a stand-alone object, or an object resident, in 
        //a container object of device-model ?? in this code-sample, we 
        //are using kobject{}, as a stand-alone system-object 
   
        //here, a kobject{} is created, initialized  and registered with 
        //device-core model(a subsystem), and also, registered with 
        //sysfs(another subsystem/another component) - many operations
        //are done, in the background, by a system-API.... 
        //initially, understand the relationship with device-core model
        //and once clear, try to understand 
        //the relationship/registration/link,
        // with 
        //sysfs pseudo fs - for every registered kobject{}, there will be 
        // a sysfs_dirent{} object set-up, in sysfs - this sysfs_dirent{} 
        //object will represent a sysfs directory and exported to user-space !!!

        //in this example, we are not using a kset(another, low-level 
        //kernel object), but a pre-existing kobject{} of device model is
        //used, as the parent-kobject - in this case, kernel_kobj is ptr to 
        //"a system's kobject, which may be used, for experimental and 
        //testing purposes" - this is one of the scenarios - in the 
        //next example(kset_example.c), we will see another scenario 

        //
        //
        //--->in this code-sample, we are using an 
        //    experimental kobject{}, as our 
        //    parent kobject - refer to parameter 2 
        //
        //in further code samples/scenarios, we will use other kobject{}s
        //, as parents ?? keep reading ... 

        //refer to <ksrc>/Documentation/kobject.txt, which is 
        //part of kernel documentation 
        //
        //refer to <ksrc>/lib/kobject.c and <ksrc>/include/linux/kobject.h
        // 
        //in the below system API, p1 is the name of the new-kobject to be
        //created - every kobject requires a name string - 
        //p2 will be ptr to a parent-kobject - the parent- 
        //kobject can be a standalone kobject, or a kobject inside 
        //another, container-object,like kset - there are different possible 
        //designs/scenarios - these are different rules of 
        //device-model .... 
        //in this context, we are passing ptr to a system-kobject to 
        // p2  - in these experimental code samples, we are
        //using pointer to a pre-existing, system-kobject - 
        //in this context, parent of our kobject will be a system-kobject - 
        //this kobject's ptr will be the second parameter ?? in other contexts, 
        //we will pass a different parent's pointer/address
        //
        //what are the actions taken, in this system API ??
        //
        //this system API creates a new kobject(step 1) - 
        //initializes the kobject's fields (step 2) - 
        //registers this new kobject, with device-model(step 3) - meaning, a 
        //link is established -  
        //next, registers this kobject,  
        //with sysfs(step 4) ?? as part of step 4, 
        //a sysfs-directory is created, for this kobject{} instance and
        //a link is established -
        //if this system API is successful, a new kobject is created
        //and registered, with device model, and also, registered,
        // with sysfs-layer -  
        //- after all the above set-up,  "we will get 
        //a ptr to the newly created kobject", as return value - 
        //this will be used,
        //as a handle to other system APIs  
        //
        //
        //
	example_kobj = kobject_create_and_add("kobject_example", kernel_kobj);
	if (!example_kobj)
		return -ENOMEM; //kobject is typically allocated from 
                                //a slab allocator and due to low physical 
                                //memory scenario, there may be a failure 
                                

	/* Create the files associated with this kobject */
        //with the help of sysfs_create_group() system-API, system will
        //create one "sysfs regular-empty file" per struct attribute{}, 
        //which are  passed via 
        //attr_group{}(param2(p2) of sysfs_create_group()), 
        //under sysfs directory entry of a 
        //kobject {}, whose pointer is passed to to param1(p1) of 
        //sysfs_create_group()  !!!

        //after registrations, 
        //there will be  sysfs_dirent{} objects of sysfs corresponding 
        //to regular-empty sysfs-files of struct attribute{} objects maintained, 
        //in the sysfs-layer  ??
        //hint: they will be maintained, under a specific 
        //sysfs_dirent{} object of kobject(passed to param1), in the sysfs !! 
        //connect the details, using the understanding and code ???
        //	
        //in this case, regular sysfs files are created for one or 
        //more struct attribute{} objects - these are created, under 
         //kobject's(param1) sysfs-directory -  
        //what is the use of these regular (empty) sysfs-files ??

        //when we are registering our struct attribute{} 
        //objects of our specific, 
        //hw-attributes' objects, with device model/sysfs, 
        //we are also, registering our "specific- 
        //attributes' call-backs" - these are show()/store() methods
        //
        //when we access our "sysfs empty-regular file" of our "specific
        // attribute's" "struct attribute{}", we are 
        //eventually, accessing our 
        //"specific-attribute's show/store call backs" - all these
        //are well taken care by the frame-works, in the background -  
        //this is what enables us to actually take actions, 
        //when a read system-call 
        //and a write system-call are invoked on a 
        //struct attribute's sysfs-file ??
        //
        //before using read()/write() system-call APIs, 
        //as part of this set-up and access, we still need to 
        //set-up an active-file of a sysfs regular-file, using 
        //open() system-call API - similar to procfs active-files, 
        //sysfs active-files are set-up, using open() system-call APi  
        //
        //these call-backs have strict prototypes - these call-backs are 
        //passed certain system-objects/private objects - 
        //these objects help us do  productive 
        //work in call-backs - 
        //these objects enable us to write re-entrant call-backs, which 
        //can be effective for several device-instances,concurrently, 
        //in several kernel-execution paths  ?? these kernel-executions
        //paths correspond to several threads of execution of 
        //one or more processes - much depends on the user-space 
        //application/code, as well  
        //======================================================================
        //assignment requires following changes :
        //
        //you need to add 2 more attributes - in this case, you must 
        //use sysfs_create_file() API for registering attributes
        //
        //we need to create 2 more attributes with appropriate names/show/store
        //you need to use a single set of show/store between the 2 attributes 
        //code, build, and test the attributes - check call trace,using dump stack ??
        //
        //====================================================================
        //p1 will be ptr. to the kobjecti of this device-instancej - in 
        //this case, it is dummy kobjecti - 
        //p2 points to a table containing multiple struct attribute{} objects -
        //this is a sysfs API - read the details above, for struct attribute{} 
        //and its use.....
        //sysfs_create_group() is used to register several 
        //struct attribute{}s of a kobjecti - actually, these struct attribute{}s
        //will represent device-instancei's specific-attributes
        //
        //read the comments discussed above 
        retval = sysfs_create_group(example_kobj, &attr_group);
	if (retval)
		kobject_put(example_kobj);


         //we may use sysfs_create_file(), if we just need to manage 
        //few attributes, under a kobject - this will be needed, in 
        //our assignment problems 

         //in the case of sysfs_create_file(p1, p2), 
         //p1 is pointer to a kobject{} of our device-instancei 
         //and p2 is a pointer to  a single struct attribute{} object of
         //a struct kobj_attribute{} of our device-instancei 
         //--->one sysfs regular file is created per 
         //struct attribute{} 
         //
         //we can uncomment and experiment some of this 
         //system APIs...
         // 
         //sysfs_create_file(example_kobj, &new_attribute1.attr);
         //sysfs_create_file(example_kobj, &new_attribute2.attr);


	return retval;
}

static void __exit example_exit(void)
{
      //we cannot directly delete a kobject{} instance, since,
      //as per rules, we must follow kobject_put(), so
      //understand and use the rules/coding  

        //this decreases the usage-counter of the respective kobject {} and
        //if the counter drops to 0, free the container object and its kobject,
        //using destructor  !!!
        //in this case, destructor is provided by the core device 
        //model/layer - implicitly, taken care  !!!

        //as per the frame-work , this one line of code /system API 
        //will do the job of clean-up of  all the above set-up, 
        //in the background   
        //
	kobject_put(example_kobj);
}

module_init(example_init);
module_exit(example_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Greg Kroah-Hartman <greg@kroah.com>");
